<?php include "../includes/db.php"?>
<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Online Assessment Portal</title>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="It is a website to assess the skills of the individual.">
        <meta name="author" content="">
        <!-- this is core bootstrap css -->
        <link type="text/css" rel="stylesheet" href="../css/bootstrap.min.css">
        <!-- Fontawesome -->
        <link rel="stylesheet" href="../font-awesome/css/font-awesome.min.css" type="text/css">
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
        <!-- custom css -->
        <link rel="stylesheet" href="../css/blog_home.css" type="text/css">
        <!-- Google fonts-->
        <link href="https://fonts.googleapis.com/css?family=Acme" rel="stylesheet">
        <style>
            .grid{
                border: 1px solid gray;
                box-shadow: lightgray 5px 5px;
                padding: 10px;
                margin: 30px;
                border-radius: 10px;
                height: 350px;
            }
            .form1{
                border: 2px solid black;
                padding: 2% 5% 5% 5%;
                margin: 0 10% 5% 10%;
                border-radius: 10px;
                background: lightgray;
                
            }
            .center 
            {
                width: 100px;
                height: 100px;
                display: block;
                margin-right: auto;
                margin-left: auto;
                margin-bottom: 30px;
                border-radius: 50%;
            }
            .button1
            {
                margin: 0 15px 0 15px;
            }
        </style>
    </head>
    <body>
    <div>   
    
                <?php
                            $right=0;
                            $wrong=0;
                            $not_attempted=0;
                   
                          $query = "SELECT ques_no,correct_answer FROM python_quiz";
                          $select_questions = mysqli_query($connection, $query);
                        
                          while($row = mysqli_fetch_assoc($select_questions))
                          {
                            $ques_no = $row['ques_no'];
                            $correct_answer = $row['correct_answer'];

                            if($correct_answer==$_POST[$ques_no])
                            {
                                $right++;
                            }
                            elseif ($_POST[$ques_no]=="not_answer") {
                                $not_attempted++;
                            }
                            else{
                                $wrong++;
                            }
                        }
                        $total_ques = $right + $wrong + $not_attempted;
                        $percentage = round(($right/$total_ques)*100);

                        header("refresh:10; url=../users/user_index.php");
                  
                        ?>
        
                        <div class="container">
                            <div class="row">
                            <div class="col-lg-12 well">
                                <center><h2>Result Of the Quiz</h2></center>
                                <table class="table table-bordered">
                                <thead>
                                    <tr class="info">
                                        <th>Category</th>
                                        <th>number</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr class="success">
                                        <td>Right</td>
                                        <td><?php echo $right;?></td>
                                    </tr>
                                    <tr class="success">
                                        <td>Wrong</td>
                                        <td><?php echo $wrong;?></td>
                                    </tr>
                                    <tr class="success">
                                        <td>Not Attempted</td>
                                        <td><?php echo $not_attempted;?></td>
                                    </tr>
                                   
                                    <tr class="success">
                                        <td>Percentage</td>
                                        <td><?php echo $percentage."%";?></td>
                                    </tr>
                                </tbody>
                                </table>
            
                                <a href="../users/user_index.php" name="result" class="btn btn-primary">Home</a>
                                <p style="color:green; float: right;">Redirecting to home page in 10 sec !!...</p>

                            </div>
                        </div>
                        
                        </div>

        </body>
        </html>




     