<?php 
$db['db_host'] = "localhost";
$db['db_user'] = "ankur";
$db['db_pass'] = "rathi";
$db['db_name'] = "online_access";

foreach ($db as $key => $value)
{
    define(strtoupper($key), $value);
}
$connection = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);
/*
if($connection)
{
    echo "we are connected";
}
else{
    die("Error:".$connection -> $error);
}
*/
?>