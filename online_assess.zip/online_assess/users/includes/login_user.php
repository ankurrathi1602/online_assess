<?php include "db.php"; ?>
<?php session_start();?>
<?php 

if(isset($_POST["login"])){
  $login_id = $_POST["login_id"];
  $password = $_POST["password"];

  $user_id = mysqli_real_escape_string($connection, $login_id);
  $password = mysqli_real_escape_string($connection, $password);

  $query = "SELECT * FROM register where email='{$user_id}'";
  $select_query= mysqli_query($connection, $query);
  if(!$select_query){
      die("ERROR".mysqli_error($connection));
  }
  while($row = mysqli_fetch_array($select_query)){
    $db_f_name = $row["f_name"];
    $db_s_name = $row["s_name"];
    $db_email = $row["email"];
    $db_password = $row["password1"];
  }
  if($user_id!== $db_email && $password !== $db_password){

    header ("Location: ../login.php?msg=error");

  }else if($user_id == $db_email && $password == $db_password){
      $_SESSION['email']=$db_email;
      $_SESSION['password1']=$db_password;
      $_SESSION['f_name']=$db_f_name;
      $_SESSION['s_name']=$db_s_name;


      header("Location: ../user_index.php");
  }else{
      header ("Location:../login.php?msg=error");
  }

}
?>