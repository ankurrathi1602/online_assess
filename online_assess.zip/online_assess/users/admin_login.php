<?php session_start();?>
<?php include "includes/header.php"; ?>

        <nav class="navbar navbar-inverse navbar-fixed-top navb1" role="navigation">
            <div class="container">
            <!-- for mobile devices-->
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="index.php">Online Assessment</a>
                </div>
                
            <!--navigations -->
                <div class="collapse navbar-collapse navbar-ex1-collapse">
                    <ul class="nav navbar-nav navbar-right side-nav">
                        <li><a href="../index.php"><i class="fa fa-fw fa-home"></i>Home</a></li>
                        <li><a href="../contact.php"><i class="fa fa-fw fa-user"></i>Contact</a></li>
                        <li><a href="register.php">Register<i class="fa fa-fw fa-login"></i></a></li>
                        <li><a href="login.php">Student Login</a></li>
                        <li class="active"><a href="#">Admin Login</a></li>

                    </ul>
                </div>
            </div>
        </nav>

        <div class="container">
            <div class="row well">
                <h2 style="text-align: center; text-decoration: underline;">Admin Login</h2>
                <div class="col-sm-12">
                    <div class="form1">
                    <img class="rounded float-right img-thumbnail center" src="images/photopng.png" alt="icon">
                    <hr>
                        <form action="../db_admin.php" method="POST">
                        <?php
                        if(isset($_GET['admin']))
                        {
                            echo "<p style='color:red;'>Only Authorised person is allowed to Login!!</p>";
                        }
                        ?>
                        <div class="form-group">
                            <label for="username">Username</label>
                            <input class="form-control" type="email" name="username" placeholder="Email" required>
                            <label for="password">Password</label>
                            <input class="form-control" type="password" name="password" placeholder="password" required>
                        </div>
                        <input class="btn btn-danger" type="submit" name="admin_login" value="Admin Login" style="text-align: center; width: 100%;">
                        <p><a href="register.php">Forgot Password<i class="fa fa-fw fa-question"></i></a></p>
                        </form>
                    </div>
                </div>
            </div>
            
        </div>


<?php include "includes/footer.php" ?>
