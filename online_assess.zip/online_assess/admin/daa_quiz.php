<?php include "includes/admin_header.php" ?>

    <div id="wrapper">

<?php include "includes/admin_navigation.php" ?>


        <div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">

                    <div class="col-lg-12">

                    <h1 class="page-header">
                            Design and Analysis of Algorithm
                            <small>Questions</small>
                    </h1>
                    <?php
                        if(isset($_POST['create_question']))
                        {
                            $question = $_POST['question'];
                            $option1 = $_POST['option1'];
                            $option2 = $_POST['option2'];
                            $option3 = $_POST['option3'];
                            $option4 = $_POST['option4'];
                            $correct_answer = $_POST['correct_answer'];



                            $query = "INSERT INTO daa_quiz(question,option1,option2,option3,option4,correct_answer)";

                            $query .= "VALUES('{$question}','{$option1}','{$option2}','{$option3}','{$option4}','{$correct_answer}')";

                            $create_ques_query = mysqli_query($connection, $query);

                            confirm_query($create_ques_query);
                        }

                        ?>


                        <form action="" method="post" enctype="multipart/form-data">
                            <div class="form-group">
                                <label for="question">Question</label>
                                <textarea class="form-control" name="question" cols="30" row="10">
                                </textarea>
                            </div>
                            <div class="form-group">
                                <label for="option1">Option1</label>
                                <input type="text" class="form-control" name="option1">
                            </div>
                            <div class="form-group">
                                <label for="option2">Option2</label>
                                <input type="text" class="form-control" name="option2">
                            </div>
                            <div class="form-group">
                                <label for="option3">Option3</label>
                                <input type="text" class="form-control" name="option3">
                            </div>
                            <div class="form-group">
                                <label for="option4">Option4</label>
                                <input type="text" class="form-control" name="option4">
                            </div>
                            <div class="form-group">
                                <label for="correct_answer">correct Answer</label>
                                <input type="text" class="form-control" name="correct_answer">
                            </div>
                            <div class="form-group"></div>
                                <input type="submit" class="btn btn-primary" name="create_question" value="Add Question">
                            </div>

                        </form>

                    </div>

                </div> <!--end of page heading-->

            </div> <!-- end of container fluid-->

        </div><!-- end of page rapper-->

<?php include "includes/admin_footer.php" ?>
